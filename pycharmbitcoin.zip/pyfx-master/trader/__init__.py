"""
pyFxTrader
"""

__author__ = 'Joseph Melettukunnel, Jonathan Stoppani'
__email__ = 'jmelett@gmail.com, jonathan@stoppani.name'
__version__ = '0.0.1'
__url__ = 'https://github.com/jmelett/pyFxTrader'
__license__ = 'MIT'
